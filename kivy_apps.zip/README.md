# Kivy Android Apps Collection

This repository contains 5 Kivy applications that can be built into Android APK files.

## Apps Included

1. **Hello World App** - A simple app that displays "Hello, World!" on the screen
2. **Calculator App** - A basic calculator with number buttons and arithmetic operations
3. **To-Do List App** - An app for adding, viewing, and deleting tasks with checkboxes
4. **Note Taking App** - An app for creating, viewing, and managing text notes
5. **Drawing App** - A simple drawing app where you can draw with your finger/mouse

## Building APKs

The repository is configured with GitHub Actions to automatically build APK files for all apps. When you push changes to this repository, GitHub Actions will build new APKs for all apps.

To download the APK files:
1. Go to the "Actions" tab
2. Select the latest workflow run
3. Scroll down to the "Artifacts" section
4. Download the APK files for each app

## Manual Building

If you prefer to build the APKs manually, you can use Docker:
```
# For each app directory, run:
docker run --rm -v "$PWD":/home/user/hostcwd kivy/buildozer android debug
```

## Requirements

- Docker (for manual building)
- Or just a GitHub account (for automatic building with GitHub Actions)