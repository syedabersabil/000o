import kivy
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.graphics import Color, Ellipse, Line
from kivy.uix.label import Label
from random import random

kivy.require('2.0.0')

class DrawingWidget(Widget):
    def __init__(self, **kwargs):
        super(DrawingWidget, self).__init__(**kwargs)
        self.color = (random(), random(), random())
        
        with self.canvas:
            Color(*self.color)
            self.line = Line(points=[], width=2)
    
    def on_touch_down(self, touch):
        with self.canvas:
            Color(*self.color)
            self.line = Line(points=(touch.x, touch.y), width=2)
    
    def on_touch_move(self, touch):
        self.line.points += [touch.x, touch.y]
    
    def clear_canvas(self):
        self.canvas.clear()
        self.color = (random(), random(), random())

class DrawingApp(App):
    def build(self):
        # Main layout
        main_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # Title
        title = Label(text='Simple Drawing App', size_hint_y=None, height=50, font_size=30)
        main_layout.add_widget(title)
        
        # Drawing widget
        self.drawing_widget = DrawingWidget()
        main_layout.add_widget(self.drawing_widget)
        
        # Buttons layout
        buttons_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        # Clear button
        clear_button = Button(text='Clear')
        clear_button.bind(on_press=lambda x: self.drawing_widget.clear_canvas())
        
        # Change color button
        color_button = Button(text='New Color')
        color_button.bind(on_press=lambda x: setattr(self.drawing_widget, 'color', (random(), random(), random())))
        
        buttons_layout.add_widget(clear_button)
        buttons_layout.add_widget(color_button)
        main_layout.add_widget(buttons_layout)
        
        return main_layout

if __name__ == '__main__':
    DrawingApp().run()