import kivy
from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput

kivy.require('2.0.0')

class CalculatorApp(App):
    def build(self):
        # Create the main layout
        main_layout = GridLayout(cols=1, padding=10, spacing=10)
        
        # Create the result display
        self.solution = TextInput(
            multiline=False, readonly=True, font_size=55, halign="right"
        )
        main_layout.add_widget(self.solution)
        
        # Create buttons
        buttons = [
            ['7', '8', '9', '/'],
            ['4', '5', '6', '*'],
            ['1', '2', '3', '-'],
            ['.', '0', 'C', '+']
        ]
        
        # Add buttons to layout
        for row in buttons:
            h_layout = GridLayout(cols=4, spacing=10)
            for label in row:
                button = Button(
                    text=label,
                    font_size=40,
                    background_color=(0.2, 0.2, 0.2, 1)  # Dark gray
                )
                button.bind(on_press=self.on_button_press)
                h_layout.add_widget(button)
            main_layout.add_widget(h_layout)
        
        # Add equals button
        equals_button = Button(
            text="=", font_size=40, background_color=(0, 0.6, 1, 1)  # Blue
        )
        equals_button.bind(on_press=self.on_solution)
        main_layout.add_widget(equals_button)
        
        return main_layout

    def on_button_press(self, instance):
        current = self.solution.text
        button_text = instance.text
        
        if button_text == "C":
            # Clear the solution widget
            self.solution.text = ""
        else:
            if current and (self.solution.text[-1] in "+-/*" and button_text in "+-/*"):
                # Don't add two operators next to each other
                return
            elif current == "" and button_text in "+-/*":
                # First character cannot be an operator
                return
            else:
                self.solution.text = current + button_text

    def on_solution(self, instance):
        text = self.solution.text
        try:
            # Evaluate the expression and display the result
            result = str(eval(self.solution.text))
            self.solution.text = result
        except:
            self.solution.text = "Error"

if __name__ == "__main__":
    CalculatorApp().run()