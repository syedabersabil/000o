import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.popup import Popup

kivy.require('2.0.0')

class NoteTakingApp(App):
    def build(self):
        # Main layout
        self.main_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # Title
        title = Label(text='Note Taking App', size_hint_y=None, height=50, font_size=30)
        self.main_layout.add_widget(title)
        
        # Notes list area
        self.notes_layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.notes_layout.bind(minimum_height=self.notes_layout.setter('height'))
        
        # ScrollView for notes
        self.scroll_view = ScrollView()
        self.scroll_view.add_widget(self.notes_layout)
        self.main_layout.add_widget(self.scroll_view)
        
        # Add note button
        add_button = Button(text='Add New Note', size_hint_y=None, height=50)
        add_button.bind(on_press=self.add_note_popup)
        self.main_layout.add_widget(add_button)
        
        # Store notes
        self.notes = []
        self.note_contents = []
        
        return self.main_layout
    
    def add_note_popup(self, instance):
        # Create popup for adding a note
        popup_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # Title input
        title_input = TextInput(hint_text='Note Title', size_hint_y=None, height=40)
        popup_layout.add_widget(title_input)
        
        # Content input
        content_input = TextInput(hint_text='Note Content', multiline=True)
        popup_layout.add_widget(content_input)
        
        # Buttons layout
        buttons_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        # Save button
        save_button = Button(text='Save')
        save_button.bind(on_press=lambda x: self.save_note(title_input.text, content_input.text, popup))
        
        # Cancel button
        cancel_button = Button(text='Cancel')
        cancel_button.bind(on_press=lambda x: popup.dismiss())
        
        buttons_layout.add_widget(save_button)
        buttons_layout.add_widget(cancel_button)
        popup_layout.add_widget(buttons_layout)
        
        # Create and open popup
        popup = Popup(title='Add New Note', content=popup_layout, size_hint=(0.8, 0.6))
        popup.open()
    
    def save_note(self, title, content, popup):
        if title.strip() or content.strip():
            # Close popup
            popup.dismiss()
            
            # Create note display
            note_layout = BoxLayout(size_hint_y=None, height=80, spacing=10)
            
            # Note title
            note_title = Label(text=title if title.strip() else "Untitled", halign='left', 
                              valign='middle', text_size=(None, None))
            
            # View button
            view_button = Button(text='View', size_hint_x=None, width=80)
            view_button.bind(on_press=lambda x: self.view_note(title, content))
            
            # Delete button
            delete_button = Button(text='Delete', size_hint_x=None, width=80)
            delete_button.bind(on_press=lambda x: self.remove_note(note_layout))
            
            # Add widgets to note layout
            note_layout.add_widget(note_title)
            note_layout.add_widget(view_button)
            note_layout.add_widget(delete_button)
            
            # Add note to the list
            self.notes_layout.add_widget(note_layout)
            self.notes.append(note_layout)
            self.note_contents.append((title, content))
    
    def view_note(self, title, content):
        # Create popup for viewing a note
        popup_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # Title
        title_label = Label(text=title if title.strip() else "Untitled", 
                           size_hint_y=None, height=40, font_size=20)
        popup_layout.add_widget(title_label)
        
        # Content display
        content_display = TextInput(text=content, readonly=True, multiline=True)
        popup_layout.add_widget(content_display)
        
        # Close button
        close_button = Button(text='Close', size_hint_y=None, height=50)
        
        # Create and open popup
        popup = Popup(title='View Note', content=popup_layout, size_hint=(0.8, 0.6))
        close_button.bind(on_press=popup.dismiss)
        popup_layout.add_widget(close_button)
        
        popup.open()
    
    def remove_note(self, note_layout):
        index = self.notes.index(note_layout)
        self.notes_layout.remove_widget(note_layout)
        self.notes.remove(note_layout)
        self.note_contents.pop(index)

if __name__ == '__main__':
    NoteTakingApp().run()