import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.checkbox import CheckBox
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout

kivy.require('2.0.0')

class TodoListApp(App):
    def build(self):
        # Main layout
        self.main_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # Title
        title = Label(text='To-Do List', size_hint_y=None, height=50, font_size=30)
        self.main_layout.add_widget(title)
        
        # Input area
        input_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)
        self.task_input = TextInput(hint_text='Enter a new task...', multiline=False)
        self.task_input.bind(on_text_validate=self.add_task)
        add_button = Button(text='Add', size_hint_x=None, width=100)
        add_button.bind(on_press=self.add_task)
        
        input_layout.add_widget(self.task_input)
        input_layout.add_widget(add_button)
        self.main_layout.add_widget(input_layout)
        
        # Task list area
        self.tasks_layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.tasks_layout.bind(minimum_height=self.tasks_layout.setter('height'))
        
        # ScrollView for tasks
        scroll_view = ScrollView()
        scroll_view.add_widget(self.tasks_layout)
        self.main_layout.add_widget(scroll_view)
        
        # Store tasks
        self.tasks = []
        
        return self.main_layout
    
    def add_task(self, instance):
        task_text = self.task_input.text.strip()
        if task_text:
            # Create task layout
            task_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)
            
            # Checkbox
            checkbox = CheckBox(size_hint_x=None, width=30)
            
            # Task label
            task_label = Label(text=task_text, halign='left', valign='middle', 
                              text_size=(None, None))
            
            # Delete button
            delete_button = Button(text='Delete', size_hint_x=None, width=80)
            
            # Bind events
            delete_button.bind(on_press=lambda x: self.remove_task(task_layout))
            
            # Add widgets to task layout
            task_layout.add_widget(checkbox)
            task_layout.add_widget(task_label)
            task_layout.add_widget(delete_button)
            
            # Add task to the list
            self.tasks_layout.add_widget(task_layout)
            self.tasks.append(task_layout)
            
            # Clear input
            self.task_input.text = ''
    
    def remove_task(self, task_layout):
        self.tasks_layout.remove_widget(task_layout)
        if task_layout in self.tasks:
            self.tasks.remove(task_layout)

if __name__ == '__main__':
    TodoListApp().run()